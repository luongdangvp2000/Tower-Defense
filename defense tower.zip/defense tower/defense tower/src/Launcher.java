public class Launcher {

    public static void main(String[] args){
        Game game = new Game("denfense tower",1280,700);
        game.start();

    }
}
